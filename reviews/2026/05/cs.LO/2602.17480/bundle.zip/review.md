# Directed type theory, with a twist

GrokRxiv review of [arXiv:2602.17480](https://arxiv.org/abs/2602.17480) · `cs.LO`

## TL;DR

This paper introduces Twisted Type Theory (TTT), a directed type theory extending North's 1-category model with a novel twisting operation and dependent 2-sided fibrations (D2SFibs). The novelty assessment is strong (score 0.85, verdict: significant), and the literature coverage is thorough and appropriate. The core categorical framework — types as categories, D2SFib straightening-unstraightening, and the natural-transformations result — is sound in outline and well-argued. However, the reproducibility specialist flagged two critical-severity gaps (no mechanized formalization of the headline TTT metatheory; no mechanized straightening-unstraightening proof) and the technical-correctness specialist flagged four major issues collectively bearing on the same root cause: the soundness of the ad hoc swap/swap^-1 rules in the category model is unestablished despite being load-bearing for the Yoneda proof; the Hom-elimination bifunctoriality argument has an implicit gap; and the judgemental status of Hom-Comp is asserted without invoking the required splitness of the cloven D2SFib explicitly. No meta-theoretic properties (subject reduction, normalization, canonicity, decidability) are established or even conjectured. These deficiencies are addressable through revision — either by mechanizing the critical components (paralleling the Coq/UniMath development cited for bicategorical type theory) or by providing explicit paper proofs for the load-bearing gaps — but they are substantial enough to require a major revision rather than minor corrections.

_Recommendation_: **Major revision** · _Confidence_: 78%

## Strengths

- The twisting operation and D2SFib framework are a genuinely novel semantic contribution that advances the state of directed type theory, satisfying a long-standing desideratum that closed types directly correspond to categories.
- The straightening-unstraightening theorem for D2SFibs (Prop prop:straight-d2sfibs) is the paper's strongest technical result: the appendix construction is explicit, the unit and counit are identified, and the categorical argument is plausible and largely complete.
- The synthetic derivation of the natural-transformations type (Prop prop:internal-nat-pi) is clean, the five-step isomorphism chain is fully cross-referenced to earlier propositions, and the result corresponds correctly to the standard end formula.
- The paper is honest about its limitations: the authors explicitly acknowledge that swap/swap^-1 are ad hoc technical tools, that the Π-type restriction is necessary to avoid a known obstruction, and that meta-theoretic properties remain open.
- Literature positioning is thorough: connections to North, Street (1974, 1980), Jacobs (1993), Licata-Harper, Ahrens-North-Van Der Weide, Riehl-Shulman, and New-Licata are all present and correctly characterized.
- Novelty relative to competing approaches is clearly articulated: TTT's semantic guarantee (closed types are categories, not bisimplicial sets) is a genuine differentiator from Simplicial Type Theory.

## Weaknesses

- No mechanized formalization is provided for any part of the TTT metatheory — syntax, twist rule, Hom rules, or category-model interpretation — despite a directly analogous Coq/UniMath formalization existing for bicategorical type theory (Ahrens–North–Van Der Weide, cited). This is a critical reproducibility gap given the complexity of the rule set. [Reproducibility: critical; C1: major]
- The soundness of the ad hoc swap/swap^-1 rules in the category model is not established. These rules are introduced solely to enable the Yoneda proof (Lemma yoneda-perm-proof) and their semantic validation is therefore load-bearing for the paper's main application. [C11: major; Reproducibility: critical]
- The Hom-elimination proof (C3) has an implicit gap: bifunctoriality of the motive D over A^→⋉X[dom]^op is invoked in the appendix diagram but never stated as a lemma or proved, and the judgemental (rather than propositional) status of Hom-Comp is asserted without explicitly invoking splitness of the cloven D2SFib. [C3: major]
- The Ψ∘Φ direction of the Yoneda proof relies on a ten-step context-isomorphism chain (Lemma yoneda-perm-proof) that the authors themselves describe as 'quite technical'; with swap/swap^-1 unverified and no mechanized check, the correctness of this argument remains under-verified. [C6: major]
- No meta-theoretic properties are established or conjectured (subject reduction, normalization, canonicity, decidability of typechecking), leaving open whether TTT is usable as a formal foundation. Comparable directed type theories (e.g., Neumann–Altenkirch via GATs) obtain admissibility of substitution by construction. [C10: minor]
- No executable prototype, reference typechecker, or regression suite is provided; readers cannot mechanically check whether the displayed derivations typecheck under the intended restrictions. [Reproducibility: major]
- The naturality-in-A-and-B argument for the fibred refinement of the D2SFib equivalence is dispatched in a single sentence; while plausible, an explicit verification is warranted given that the fibred structure is relied upon downstream. [C2: info, but worth addressing]

## Open Questions

- Can the swap/swap^-1 rules be derived from more primitive TTT rules (e.g., via the op-Σ interaction and straightening), or are they genuinely independent postulates? If independent, what is the explicit categorical operation they correspond to in the category model, and can their soundness be proved directly from the D2SFib structure?
- How does TTT relate to Neumann–Altenkirch's generalized-algebraic-theory presentation of directed type theory? In particular, does TTT admit a GAT presentation, and would that yield admissibility of substitution and subject reduction as standard consequences?
- The Π-type restriction (requiring Γ^op ⊢ A and Γ⋉^- a:A ⊢ B) is presented as necessary to avoid the opfibration obstruction — is there a concrete counterexample demonstrating that unrestricted Π would fail, or is the restriction merely known to be sufficient?
- What is the intended strategy for extending TTT to higher-categorical settings such as (∞,1)-categories or bicategories, and does the twisting operation generalize cleanly, or does it require fundamentally new semantic machinery at each level?

## Per-Agent Reviews

### citation (`gemini-3-flash-preview`) — status: `fail`

```json
{
  "confidence": 0.95,
  "entries": [
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Jean Bénabou"
        ],
        "doi": null,
        "key": "benabou2000distributors",
        "raw": "benabou2000distributors: title = {Distributors at work}, author = {B{\\'e}nabou, Jean}, year = {2000}, url = {https://www2.mathematik.tu-darmstadt.de/ streicher/FIBR/DiWo.pdf}, pubstate = {prepublished}",
        "title": "Distributors at work",
        "url": "https://www2.mathematik.tu-darmstadt.de/ streicher/FIBR/DiWo.pdf",
        "venue": "Prepublished",
        "year": 2000
      },
      "exists": null,
      "explanation": "Cited for a well-known straightening-unstraightening result for distributors (profunctors).",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Syméon Bozapalides"
        ],
        "doi": null,
        "key": "bozapalides1976theorie",
        "raw": "bozapalides1976theorie: title = {Th{\\'e}orie formelle des bicat{\\'e}gories}, author = {Bozapalides, Sym{\\'e}on}, year = {1976}, publisher = {Ehresmann, Bastiani}, url = {https://ncatlab.org/nlab/files/BOZAPALIDES_theorie_formelle_bicategories.pdf}",
        "title": "Théorie formelle des bicatégories",
        "url": "https://ncatlab.org/nlab/files/BOZAPALIDES_theorie_formelle_bicategories.pdf",
        "venue": "Ehresmann, Bastiani",
        "year": 1976
      },
      "exists": null,
      "explanation": "Included in bibliography but not explicitly cited in the provided contexts. Likely provides background on bicategories.",
      "notes": null,
      "relevance": "low",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Martin Hofmann"
        ],
        "doi": "10.1017/CBO9780511526619.004",
        "key": "hofmannSyntaxSemanticsDependent1997",
        "raw": "hofmannSyntaxSemanticsDependent1997: title = {Syntax and {{Semantics}} of {{Dependent Types}}}, booktitle = {Semantics and {{Logics}} of {{Computation}}}, author = {Hofmann, Martin}, editor = {Pitts, Andrew M. and Dybjer, P.}, year = 1997, month = jan, edition = {1}, pages = {79--130}, publisher = {Cambridge University Press}, doi = {10.1017/CBO9780511526619.004}, urldate = {2024-03-08}, isbn = {978-0-521-58057-1 978-0-521-11846-0 978-0-511-52661-9}, file = {/home/fernando/Zotero/storage/6VQDN7HI/Syntax and Semantics of Dependent Types - Hofmann.djvu}",
        "title": "Syntax and Semantics of Dependent Types",
        "url": null,
        "venue": "Semantics and Logics of Computation",
        "year": 1997
      },
      "exists": null,
      "explanation": "Cited as a survey for the copy of Martin-Löf Type Theory (MLTT) used in the paper.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Fosco Loregian"
        ],
        "doi": null,
        "key": "loregianCoendCalculus2021",
        "raw": "loregianCoendCalculus2021: title = {({{Co}})End {{Calculus}}}, author = {Loregian, Fosco}, year = 2021, series = {London {{Mathematical Society Lecture Note Ser}}}, number = {v.468}, publisher = {Cambridge University Press}, address = {Cambridge}, abstract = {This easy-to-cite handbook gives the first systematic treatment of the (co)end calculus in category theory and its applications}, isbn = {978-1-108-78860-1}, langid = {english}",
        "title": "(Co)End Calculus",
        "url": null,
        "venue": "London Mathematical Society Lecture Note Ser",
        "year": 2021
      },
      "exists": null,
      "explanation": "Cited for a straightening-unstraightening result (Theorem 5.1).",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Bart Jacobs"
        ],
        "doi": null,
        "key": "jacobsCategoricalLogicType2001",
        "raw": "jacobsCategoricalLogicType2001: title = {Categorical Logic and Type Theory}, author = {Jacobs, Bart}, year = 2001, series = {Studies in Logic and the Foundations of Mathematics}, edition = {paperback ed}, number = {141}, publisher = {Elsevier}, address = {Amsterdam}, isbn = {978-0-444-50853-9 978-0-444-50170-7}, langid = {english}, file = {/home/fernando/Zotero/storage/I2G5KHIP/Jacobs - 2001 - Categorical logic and type theory.pdf}",
        "title": "Categorical Logic and Type Theory",
        "url": null,
        "venue": "Elsevier",
        "year": 2001
      },
      "exists": null,
      "explanation": "Standard reference for categorical semantics, though the paper mostly cites his 1993 paper for comprehension categories.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Benedikt Ahrens",
          "Paige Randall North",
          "Niels Van Der Weide"
        ],
        "doi": "10.1017/S0960129523000312",
        "key": "ahrensBicategoricalTypeTheory2023",
        "raw": "ahrensBicategoricalTypeTheory2023: title = {Bicategorical Type Theory: Semantics and Syntax}, shorttitle = {Bicategorical Type Theory}, author = {Ahrens, Benedikt and North, Paige Randall and Van Der Weide, Niels}, year = 2023, month = nov, journal = {Mathematical Structures in Computer Science}, volume = {33}, number = {10}, pages = {868--912}, issn = {0960-1295, 1469-8072}, doi = {10.1017/S0960129523000312}, urldate = {2026-01-23}, abstract = {Abstract We develop semantics and syntax for bicategorical type theory. Bicategorical type theory features contexts, types, terms, and directed reductions between terms. This type theory is naturally interpreted in a class of structured bicategories. We start by developing the semantics, in the form of comprehension bicategories . Examples of comprehension bicategories are plentiful; we study both specific examples as well as classes of examples constructed from other data. From the notion of comprehension bicategory, we extract the syntax of bicategorical type theory, that is, judgment forms and structural inference rules. We prove soundness of the rules by giving an interpretation in any comprehension bicategory. The semantic aspects of our work are fully checked in the Coq proof assistant, based on the UniMath library.}, langid = {english}, file = {/home/fernando/Zotero/storage/AF5JEPQT/Ahrens et al. - 2023 - Bicategorical type theory semantics and syntax.pdf}",
        "title": "Bicategorical Type Theory: Semantics and Syntax",
        "url": null,
        "venue": "Mathematical Structures in Computer Science",
        "year": 2023
      },
      "exists": null,
      "explanation": "Cited as an example of a directed type theory that generalizes previous work by giving contexts a bicategorical structure.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Cyril Cohen",
          "Thierry Coquand",
          "Simon Huber",
          "Anders Mörtberg"
        ],
        "doi": "10.4230/LIPICS.TYPES.2015.5",
        "key": "cohenCubicalTypeTheory2018",
        "raw": "cohenCubicalTypeTheory2018: title = {Cubical {{Type Theory}}: {{A Constructive Interpretation}} of the {{Univalence Axiom}}}, shorttitle = {Cubical {{Type Theory}}}, author = {Cohen, Cyril and Coquand, Thierry and Huber, Simon and M{\\\"o}rtberg, Anders}, editor = {Uustalu, Tarmo}, year = 2018, journal = {LIPIcs, Volume 69, TYPES 2015}, volume = {69}, pages = {5:1-5:34}, publisher = {Schloss Dagstuhl -- Leibniz-Zentrum f\\\"ur Informatik}, issn = {1868-8969}, doi = {10.4230/LIPICS.TYPES.2015.5}, urldate = {2026-01-23}, abstract = {This paper presents a type theory in which it is possible to directly manipulate \\$n\\$-dimensional cubes (points, lines, squares, cubes, etc.) based on an interpretation of dependent type theory in a cubical set model. This enables new ways to reason about identity types, for instance, function extensionality is directly provable in the system. Further, Voevodsky's univalence axiom is provable in this system. We also explain an extension with some higher inductive types like the circle and propositional truncation. Finally we provide semantics for this cubical type theory in a constructive meta-theory.}, copyright = {Creative Commons Attribution 3.0 Unported license, info:eu-repo/semantics/openAccess}, isbn = {9783959770309}, langid = {english}, keywords = {cubical sets,dependent type theory,univalence axiom}",
        "title": "Cubical Type Theory",
        "url": null,
        "venue": "LIPIcs, Volume 69, TYPES 2015",
        "year": 2018
      },
      "exists": null,
      "explanation": "Cited for comparison with Riehl & Shulman's work, which also uses a calculus of shapes.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Max S. New",
          "Daniel R. Licata"
        ],
        "doi": "10.1007/978-3-031-30829-1_6",
        "key": "newFormalLogicFormal2023",
        "raw": "newFormalLogicFormal2023: title = {A {{Formal Logic}} for {{Formal Category Theory}}}, booktitle = {Foundations of {{Software Science}} and {{Computation Structures}}}, author = {New, Max S. and Licata, Daniel R.}, editor = {Kupferman, Orna and Sobocinski, Pawel}, year = {2023}, volume = {13992}, pages = {113--134}, publisher = {Springer Nature Switzerland}, location = {Cham}, doi = {10.1007/978-3-031-30829-1_6}, urldate = {2026-01-22}, abstract = {Abstract We present a domain-specific type theory for constructions and proofs in category theory. The type theory axiomatizes notions of category, functor, profunctor and a generalized form of natural transformations. The type theory imposes an ordered linear restriction on standard predicate logic, which guarantees that all functions between categories are functorial, all relations are profunctorial, and all transformations are natural by construction, with no separate proofs necessary. Important category-theoretic proofs such as the Yoneda lemma and Co-yoneda lemma become simple type-theoretic proofs about the relationship between unit, tensor and (ordered) function types, and can be seen to be ordered refinements of theorems in predicate logic. The type theory is sound and complete for a categorical model in virtual equipments , which model both internal and enriched category theory. While the proofs in our type theory look like standard set-based arguments, the syntactic discipline ensure that all proofs and constructions carry over to enriched and internal settings as well.}, isbn = {978-3-031-30828-4 978-3-031-30829-1}, langid = {english}, file = {/home/fernando/Zotero/storage/2QSWSHZX/New and Licata - 2023 - A Formal Logic for Formal Category Theory.pdf}",
        "title": "A Formal Logic for Formal Category Theory",
        "url": null,
        "venue": "Foundations of Software Science and Computation Structures",
        "year": 2023
      },
      "exists": null,
      "explanation": "Cited as a directed type theory based on virtual equipments.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": "2410.06792",
        "authors": [
          "Hayato Nasu"
        ],
        "doi": "10.48550/ARXIV.2410.06792",
        "key": "nasuInternalLogicVirtual2024",
        "raw": "nasuInternalLogicVirtual2024: title = {An {{Internal Logic}} of {{Virtual Double Categories}}}, author = {Nasu, Hayato}, year = {2024}, doi = {10.48550/ARXIV.2410.06792}, urldate = {2026-01-22}, abstract = {We present a type theory called fibrational virtual double type theory (FVDblTT) designed specifically for formal category theory, which is a succinct reformulation of New and Licata's Virtual Equipment Type Theory (VETT). FVDblTT formalizes reasoning on isomorphisms that are commonly employed in category theory. Virtual double categories are one of the most successful frameworks for developing formal category theory, and FVDblTT has them as a theoretical foundation. We validate its worth as an internal language of virtual double categories by providing a syntax-semantics duality between virtual double categories and specifications in FVDblTT as a biadjunction.}, pubstate = {prepublished}, version = {2}, keywords = {18C50 18D70 18N10(Primary) 68Q65 18D60 (Secondary),Category Theory (math.CT),FOS: Computer and information sciences,FOS: Mathematics,Logic in Computer Science (cs.LO)}",
        "title": "An Internal Logic of Virtual Double Categories",
        "url": null,
        "venue": "arXiv",
        "year": 2024
      },
      "exists": null,
      "explanation": "Cited as a directed type theory based on virtual double categories.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Benedikt Ahrens",
          "Paige Randall North",
          "Niels Van Der Weide"
        ],
        "doi": "10.1145/3531130.3533334",
        "key": "ahrensSemanticsTwodimensionalType2022",
        "raw": "ahrensSemanticsTwodimensionalType2022: title = {Semantics for Two-Dimensional Type Theory}, booktitle = {Proceedings of the 37th {{Annual ACM}}/{{IEEE Symposium}} on {{Logic}} in {{Computer Science}}}, author = {Ahrens, Benedikt and North, Paige Randall and Van Der Weide, Niels}, date = {2022-08-02}, pages = {1--14}, publisher = {ACM}, location = {Haifa Israel}, doi = {10.1145/3531130.3533334}, urldate = {2026-01-22}, eventtitle = {{{LICS}} '22: 37th {{Annual ACM}}/{{IEEE Symposium}} on {{Logic}} in {{Computer Science}}}, isbn = {978-1-4503-9351-5}, langid = {english}, file = {/home/fernando/Zotero/storage/6E43HRLE/Ahrens et al. - 2022 - Semantics for two-dimensional type theory.pdf}",
        "title": "Semantics for Two-Dimensional Type Theory",
        "url": null,
        "venue": "Proceedings of the 37th Annual ACM/IEEE Symposium on Logic in Computer Science",
        "year": 2022
      },
      "exists": null,
      "explanation": "Included in bibliography but not explicitly cited in the provided contexts. Likely related to the categorical semantics of 2D type theory.",
      "notes": null,
      "relevance": "low",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Thierry Coquand"
        ],
        "doi": null,
        "key": "coquandPresheafModelType2013",
        "raw": "coquandPresheafModelType2013: title = {Presheaf Model of Type Theory}, author = {Coquand, Thierry}, year = {2013}, url = {https://www.cse.chalmers.se/ coquand/presheaf.pdf}, pubstate = {prepublished}",
        "title": "Presheaf Model of Type Theory",
        "url": "https://www.cse.chalmers.se/ coquand/presheaf.pdf",
        "venue": "Prepublished",
        "year": 2013
      },
      "exists": null,
      "explanation": "Cited for the assumption of Coquand universes in the categorical model.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Charles Rezk"
        ],
        "doi": null,
        "key": "rezk1996model",
        "raw": "rezk1996model: title = {A model category for categories}, author = {Rezk, Charles}, year = {1996}, url = {https://ncatlab.org/nlab/files/Rezk_ModelCategoryForCategories.pdf}, pubstate = {prepublished}",
        "title": "A model category for categories",
        "url": "https://ncatlab.org/nlab/files/Rezk_ModelCategoryForCategories.pdf",
        "venue": "Prepublished",
        "year": 1996
      },
      "exists": null,
      "explanation": "Background reference for models of category theory, though not explicitly cited in text snippets.",
      "notes": null,
      "relevance": "low",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Paige Randall North"
        ],
        "doi": "10.17863/CAM.11207",
        "key": "northTypeTheoreticWeak2017",
        "raw": "northTypeTheoreticWeak2017: title = {Type Theoretic Weak Factorization Systems}, author = {North, Paige Randall}, year = 2017, month = jun, doi = {10.17863/CAM.11207}, urldate = {2026-01-30}, abstract = {This thesis presents a characterization of those categories with weak factorization systems that can interpret the theory of intensional dependent type theory with {$\\Sigma$}, {$\\Pi$}, and identity types. We use display map categories to serve as models of intensional dependent type theory. If a display map category (C, D) models {$\\Sigma$} and identity types, then this structure generates a weak factorization system (L, R). Moreover, we show that if the underlying category C is Cauchy complete, then (C, R) is also a display map category modeling {$\\Sigma$} and identity types (as well as {$\\Pi$} types if (C, D) models {$\\Pi$} types). Thus, our main result is to characterize display map categories (C, R) which model {$\\Sigma$} and identity types and where R is part of a weak factorization system (L, R) on the category C. We offer three such characterizations and show that they are all equivalent when C has all finite limits. The first is that the weak factorization system (L, R) has the properties that L is stable under pullback along R and all maps to a terminal object are in R. We call such weak factorization systems type theoretic. The second is that the weak factorization system has what we call an Id-presentation: it can be built from certain categorical structure in the same way that a model of {$\\Sigma$} and identity types generates a weak factorization system. The third is that the weak factorization system (L, R) is generated by a Moore relation system. This is a technical tool used to establish the equivalence between the first and second characterizations described. To conclude the thesis, we describe a certain class of convenient categories of topological spaces (a generalization of compactly generated weak Hausdorff spaces). We then... [truncated]",
        "title": "Type Theoretic Weak Factorization Systems",
        "url": null,
        "venue": "Thesis",
        "year": 2017
      },
      "exists": null,
      "explanation": "Author's thesis providing background on weak factorization systems in type theory.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Steve Awodey",
          "Michael A. Warren"
        ],
        "doi": "10.1017/S0305004108001783",
        "key": "awodeyHomotopyTheoreticModels2009",
        "raw": "awodeyHomotopyTheoreticModels2009: title = {Homotopy Theoretic Models of Identity Types}, author = {Steve Awodey and Michael A. Warren}, year = 2009, month = jan, journal = {Mathematical Proceedings of the Cambridge Philosophical Society}, volume = {146}, number = {1}, pages = {45--55}, issn = {0305-0041, 1469-8064}, doi = {10.1017/S0305004108001783}, urldate = {2025-02-17}, abstract = {Quillen [17] introduced model categories as an abstract framework for homotopy theory which would apply to a wide range of mathematical settings. By all accounts this program has been a success and---as, e.g., the work of Voevodsky on the homotopy theory of schemes [15] or the work of Joyal [11, 12] and Lurie [13] on quasicategories seem to indicate---it will likely continue to facilitate mathematical advances. In this paper we present a novel connection between model categories and mathematical logic, inspired by the groupoid model of (intensional) Martin--L\\\"of type theory [14] due to Hofmann and Streicher [9]. In particular, we show that a form of Martin--L\\\"of type theory can be soundly modelled in any model category. This result indicates moreover that any model category has an associated ``internal language'' which is itself a form of Martin-L\\\"of type theory. This suggests applications both to type theory and to homotopy theory. Because Martin--L\\\"of type theory is, in one form or another, the theoretical basis for many of the computer proof assistants currently in use, such as Coq and Agda (cf. [3] and [5]), this promise of applications is of a practical, as well as theoretical, nature.}, copyright = {https://www.cambridge.org/core/terms}, langid = {english}, file = {/home/fernando/Zotero/storage/DKARBPZS/Awodey and Warren - 2009 - Homotopy theoretic models of identity types.pdf}",
        "title": "Homotopy Theoretic Models of Identity Types",
        "url": null,
        "venue": "Mathematical Proceedings of the Cambridge Philosophical Society",
        "year": 2009
      },
      "exists": null,
      "explanation": "Cited for the interpretation of identity types in model categories via factorizations of the diagonal map.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Alexander Grothendieck",
          "Michèle Raynaud"
        ],
        "doi": null,
        "key": "grothendieckRevetementsEtalesGroupe2003",
        "raw": "grothendieckRevetementsEtalesGroupe2003: title = {{Rev\\^etements \\'etales et groupe fondamental (SGA1)}}, shorttitle = {{Rev\\^etements \\'etales et groupe fondamental}}, editor = {Grothendieck, Alexander and Raynaud, Mich{\\`e}le}, year = 2003, series = {{Documents math\\'ematiques}}, number = {3}, publisher = {Soc. Math\\'ematique de France}, address = {Paris}, isbn = {978-2-85629-141-2}, langid = {fre}",
        "title": "Revêtements étales et groupe fondamental (SGA1)",
        "url": null,
        "venue": "Soc. Mathématique de France",
        "year": 2003
      },
      "exists": null,
      "explanation": "Cited for the perspective on comprehension categories via the Grothendieck construction.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Ross Street"
        ],
        "doi": "10.1007/BFb0063102",
        "key": "streetFibrationsYonedasLemma1974",
        "raw": "streetFibrationsYonedasLemma1974: title = {Fibrations and {{Yoneda}}'s Lemma in a 2-Category}, booktitle = {Category {{Seminar}}}, author = {Street, Ross}, editor = {Kelly, Gregory M.}, year = 1974, volume = {420}, pages = {104--133}, publisher = {Springer Berlin Heidelberg}, address = {Berlin, Heidelberg}, doi = {10.1007/BFb0063102}, urldate = {2025-01-13}, copyright = {http://www.springer.com/tdm}, isbn = {978-3-540-06966-9 978-3-540-37270-7}, file = {/home/fernando/Zotero/storage/JX7NRFE4/Street - 1974 - Fibrations and Yoneda's lemma in a 2-category.pdf}",
        "title": "Fibrations and Yoneda's Lemma in a 2-Category",
        "url": null,
        "venue": "Category Seminar",
        "year": 1974
      },
      "exists": null,
      "explanation": "Fundamental reference for 2-sided fibrations, which the paper generalizes to the dependent case.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Peter Dybjer"
        ],
        "doi": "10.1007/3-540-61780-9_66",
        "key": "dybjerInternalTypeTheory1996",
        "raw": "dybjerInternalTypeTheory1996: title = {Internal Type Theory}, booktitle = {Types for {{Proofs}} and {{Programs}}}, author = {Dybjer, Peter}, editor = {Berardi, Stefano and Coppo, Mario}, editora = {Goos, Gerhard and Hartmanis, Juris and Leeuwen, Jan}, editoratype = {redactor}, date = {1996}, volume = {1158}, pages = {120--134}, publisher = {Springer Berlin Heidelberg}, location = {Berlin, Heidelberg}, doi = {10.1007/3-540-61780-9_66}, url = {http://link.springer.com/10.1007/3-540-61780-9_66}, urldate = {2025-02-24}, isbn = {978-3-540-61780-8 978-3-540-70722-6}, file = {/home/fernando/Zotero/storage/EEPQQLVJ/Dybjer - 1996 - Internal type theory.pdf}",
        "title": "Internal Type Theory",
        "url": "http://link.springer.com/10.1007/3-540-61780-9_66",
        "venue": "Types for Proofs and Programs",
        "year": 1996
      },
      "exists": null,
      "explanation": "Background reference for internal type theory, not explicitly cited in provided contexts.",
      "notes": null,
      "relevance": "low",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": "2503.10868",
        "authors": [
          "Niyousha Najmaei",
          "Niels van der Weide",
          "Benedikt Ahrens",
          "Paige Randall North"
        ],
        "doi": "10.48550/ARXIV.2503.10868",
        "key": "najmaeiTypeTheoryComprehension2025",
        "raw": "najmaeiTypeTheoryComprehension2025: title = {A {{Type Theory}} for {{Comprehension Categories}} with {{Applications}} to {{Subtyping}}}, author = {Najmaei, Niyousha and family=Weide, given=Niels, prefix=van der, useprefix=true and Ahrens, Benedikt and North, Paige Randall}, date = {2025}, doi = {10.48550/ARXIV.2503.10868}, url = {https://arxiv.org/abs/2503.10868}, urldate = {2025-10-06}, abstract = {In this paper we develop a type theory that we show is an internal language for comprehension categories. This type theory is closely related to Martin-Löf type theory (MLTT). Indeed, semantics of MLTT are often given in comprehension categories, albeit usually only in discrete or full ones. As we explain, requiring a comprehension category to be full or discrete can be understood as removing one `dimension' of morphisms. Thus, in our syntax, we recover this extra dimension. We show that this extra dimension can be used to encode subtyping in a natural way. Important instances of non-full comprehension categories include ones used for constructive or univalent intensional models of MLTT and directed type theory, and so our syntax is a more faithful internal language for these than is MLTT.}, pubstate = {prepublished}, version = {1}, keywords = {Category Theory (math.CT),FOS: Computer and information sciences,FOS: Mathematics,Logic in Computer Science (cs.LO),Programming Languages (cs.PL)}",
        "title": "A Type Theory for Comprehension Categories with Applications to Subtyping",
        "url": "https://arxiv.org/abs/2503.10868",
        "venue": "arXiv",
        "year": 2025
      },
      "exists": null,
      "explanation": "Included in bibliography but not explicitly cited in text snippets. Likely related to the internal language of comprehension categories.",
      "notes": null,
      "relevance": "low",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Benedikt Ahrens",
          "Peter LeFanu Lumsdaine"
        ],
        "doi": "10.23638/LMCS-15(1:20)2019",
        "key": "ahrensDisplayedCategories2019",
        "raw": "ahrensDisplayedCategories2019: title = {Displayed {{Categories}}}, author = {Ahrens, Benedikt and Lumsdaine, Peter LeFanu}, date = {2019-03-05}, journaltitle = {Logical Methods in Computer Science}, volume = {Volume 15, Issue 1}, pages = {4308}, issn = {1860-5974}, doi = {10.23638/LMCS-15(1:20)2019}, urldate = {2025-10-03}, abstract = {We introduce and develop the notion of *displayed categories*. A displayed category over a category C is equivalent to \\&quot;a category D and functor F : D --\\&gt; C\\&quot;, but instead of having a single collection of \\&quot;objects of D\\&quot; with a map to the objects of C, the objects are given as a family indexed by objects of C, and similarly for the morphisms. This encapsulates a common way of building categories in practice, by starting with an existing category and adding extra data/properties to the objects and morphisms. The interest of this seemingly trivial reformulation is that various properties of functors are more naturally defined as properties of the corresponding displayed categories. Grothendieck fibrations, for example, when defined as certain functors, use equality on objects in their definition. When defined instead as certain displayed categories, no reference to equality on objects is required. Moreover, almost all examples of fibrations in nature are, in fact, categories whose standard construction can be seen as going via displayed categories. We therefore propose displayed categories as a basis for the development of fibrations in the type-theoretic setting, and similarly for various other notions whose classical definitions involve equality on objects. Besides giving a conceptual clarification of such issues, displayed categories also provide a powerful tool in computer formalisation, unifying and abstracting common constructions and proof techniques of category theory, and enabling modular reasoning about categories of multi-component structures. As such, most of the material of this article has be... [truncated]",
        "title": "Displayed Categories",
        "url": null,
        "venue": "Logical Methods in Computer Science",
        "year": 2019
      },
      "exists": null,
      "explanation": "Cited for the notion of 'displayed category' used to study functors to a base category.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Bart Jacobs"
        ],
        "doi": "10.1016/0304-3975(93)90169-T",
        "key": "jacobsComprehensionCategoriesSemantics1993",
        "raw": "jacobsComprehensionCategoriesSemantics1993: title = {Comprehension Categories and the Semantics of Type Dependency}, author = {Jacobs, Bart}, date = {1993-01}, journaltitle = {Theoretical Computer Science}, shortjournal = {Theoretical Computer Science}, volume = {107}, number = {2}, pages = {169--207}, issn = {03043975}, doi = {10.1016/0304-3975(93)90169-T}, urldate = {2024-05-02}, langid = {english}, file = {/home/fernando/Zotero/storage/W5L5W3XF/Jacobs - 1993 - Comprehension categories and the semantics of type.pdf}",
        "title": "Comprehension Categories and the Semantics of Type Dependency",
        "url": null,
        "venue": "Theoretical Computer Science",
        "year": 1993
      },
      "exists": null,
      "explanation": "Cited for showing that full split comprehension categories provide semantics for MLTT.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Ross Street"
        ],
        "doi": null,
        "key": "street_fibrations_1980",
        "raw": "street_fibrations_1980: title = {Fibrations in bicategories}, volume = {21}, url = {http://www.numdam.org/item/CTGDC_1980__21_2_111_0/}, language = {en}, number = {2}, journal = {Cahiers de topologie et géométrie différentielle}, author = {Street, Ross}, year = {1980}, note = {(Corrections in 28(1):53–56, 1987)}, pages = {111--160}, file = {Street - 1980 - Fibrations in bicategories.pdf:/home/fernando/Zotero/storage/5IP4T9XM/Street - 1980 - Fibrations in bicategories.pdf:application/pdf}",
        "title": "Fibrations in bicategories",
        "url": "http://www.numdam.org/item/CTGDC_1980__21_2_111_0/",
        "venue": "Cahiers de topologie et géométrie différentielle",
        "year": 1980
      },
      "exists": null,
      "explanation": "Cited for the observation that the $\\langle dom, cod \\rangle$ functor is a Grothendieck construction on a profunctor.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Fernando Chu",
          "Éléonore Mangel",
          "Paige Randall North"
        ],
        "doi": null,
        "key": "chu_fernando_directed_2024",
        "raw": "chu_fernando_directed_2024: title = {A directed type theory for 1-categories}, booktitle = {30th {International} {Conference} on {Types} for {Proofs} and {Programs} ({TYPES} 2024)}, author = {{Chu, Fernando} and {Mangel, Éléonore} and {North, Paige Randall}}, year = {2024}",
        "title": "A directed type theory for 1-categories",
        "url": null,
        "venue": "TYPES 2024",
        "year": 2024
      },
      "exists": null,
      "explanation": "Earlier version or related work by the authors on directed type theory.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Martin Hofmann",
          "Thomas Streicher"
        ],
        "doi": null,
        "key": "hofmann_groupoid_1998",
        "raw": "hofmann_groupoid_1998: title = {The groupoid interpretation of type theory}, booktitle = {Twenty-{Five} {Years} of {Constructive} {Type} {Theory}}, publisher = {Oxford University Press}, author = {Hofmann, Martin and Thomas Streicher}, year = {1998}, pages = {83--111}, file = {Hofmann and Streicher - 1998 - The groupoid interpretation of type theory.pdf:/home/fernando/Zotero/storage/Q7YWQ2X7/Hofmann and Streicher - 1998 - The groupoid interpretation of type theory.pdf:application/pdf}",
        "title": "The groupoid interpretation of type theory",
        "url": null,
        "venue": "Twenty-Five Years of Constructive Type Theory",
        "year": 1998
      },
      "exists": null,
      "explanation": "Cited for the seminal groupoid model of MLTT.",
      "notes": null,
      "relevance": "high",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Lisbeth Fajstrup",
          "Eric Goubault",
          "Emmanuel Haucourt",
          "Samuel Mimram",
          "Martin Raussen"
        ],
        "doi": "10.1007/978-3-319-15398-8",
        "key": "fajstrup_directed_2016",
        "raw": "fajstrup_directed_2016: address = {Cham}, title = {Directed {Algebraic} {Topology} and {Concurrency}}, copyright = {http://www.springer.com/tdm}, isbn = {978-3-319-15397-1 978-3-319-15398-8}, url = {http://link.springer.com/10.1007/978-3-319-15398-8}, language = {en}, urldate = {2025-02-17}, publisher = {Springer International Publishing}, author = {Fajstrup, Lisbeth and Goubault, Eric and Haucourt, Emmanuel and Mimram, Samuel and Raussen, Martin}, year = {2016}, doi = {10.1007/978-3-319-15398-8}",
        "title": "Directed Algebraic Topology and Concurrency",
        "url": "http://link.springer.com/10.1007/978-3-319-15398-8",
        "venue": "Springer International Publishing",
        "year": 2016
      },
      "exists": null,
      "explanation": "Background reference for directed homotopy theory and its applications.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Benedikt Ahrens",
          "Paige Randall North",
          "Michael Shulman",
          "Dimitris Tsementzis"
        ],
        "doi": "10.1145/3373718.3394755",
        "key": "ahrens_higher_2020",
        "raw": "ahrens_higher_2020: address = {Saarbrücken Germany}, title = {A {Higher} {Structure} {Identity} {Principle}}, isbn = {978-1-4503-7104-9}, doi = {10.1145/3373718.3394755}, language = {en}, urldate = {2024-10-17}, booktitle = {Proceedings of the 35th {Annual} {ACM}/{IEEE} {Symposium} on {Logic} in {Computer} {Science}}, publisher = {ACM}, author = {Ahrens, Benedikt and North, Paige Randall and Michael Shulman and Dimitris Tsementzis}, month = jul, year = {2020}, pages = {53--66}, file = {Full Text:/home/fernando/Zotero/storage/CDYPWQST/Ahrens et al. - 2020 - A Higher Structure Identity Principle.pdf:application/pdf}",
        "title": "A Higher Structure Identity Principle",
        "url": null,
        "venue": "Proceedings of the 35th Annual ACM/IEEE Symposium on Logic in Computer Science",
        "year": 2020
      },
      "exists": null,
      "explanation": "Cited for the Structure Identity Principle (SIP) in HoTT.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Guillaume Brunerie"
        ],
        "doi": "10.1007/s10817-018-9468-2",
        "key": "brunerie_james_2019",
        "raw": "brunerie_james_2019: title = {The {James} {Construction} and $\\pi_4(\\mathbb{S}^3)$ in {Homotopy} {Type} {Theory}}, volume = {63}, issn = {0168-7433, 1573-0670}, doi = {10.1007/s10817-018-9468-2}, language = {en}, number = {2}, urldate = {2025-02-20}, journal = {Journal of Automated Reasoning}, author = {Brunerie, Guillaume}, month = aug, year = {2019}, pages = {255--284}",
        "title": "The James Construction and pi4(S3) in Homotopy Type Theory",
        "url": null,
        "venue": "Journal of Automated Reasoning",
        "year": 2019
      },
      "exists": null,
      "explanation": "Cited as an example of synthetic reasoning about homotopy groups in HoTT.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "András Kovács"
        ],
        "doi": "10.4230/LIPICS.CSL.2022.28",
        "key": "kovacs_generalized_2022",
        "raw": "kovacs_generalized_2022: title = {Generalized {Universe} {Hierarchies} and {First}-{Class} {Universe} {Levels}}, volume = {216}, copyright = {Creative Commons Attribution 4.0 International license, info:eu-repo/semantics/openAccess}, issn = {1868-8969}, doi = {10.4230/LIPICS.CSL.2022.28}, abstract = {In type theories, universe hierarchies are commonly used to increase the expressive power of the theory while avoiding inconsistencies arising from size issues. There are numerous ways to specify universe hierarchies, and theories may differ in details of cumulativity, choice of universe levels, specification of type formers and eliminators, and available internal operations on levels. In the current work, we aim to provide a framework which covers a large part of the design space. First, we develop syntax and semantics for cumulative universe hierarchies, where levels may come from any set equipped with a transitive well-founded ordering. In the semantics, we show that induction-recursion can be used to model transfinite hierarchies, and also support lifting operations on type codes which strictly preserve type formers. Then, we consider a setup where universe levels are first-class types and subject to arbitrary internal reasoning. This generalizes the bounded polymorphism features of Coq and at the same time the internal level computations in Agda.}, language = {en}, urldate = {2025-03-01}, journal = {LIPIcs, Volume 216, CSL 2022}, author = {Kovács, András}, collaborator = {Manea, Florin and Simpson, Alex}, year = {2022}, keywords = {Theory of computation â†’ Type theory, type theory, universes}, pages = {28:1--28:17}",
        "title": "Generalized Universe Hierarchies and First-Class Universe Levels",
        "url": null,
        "venue": "LIPIcs, Volume 216, CSL 2022",
        "year": 2022
      },
      "exists": null,
      "explanation": "Cited for the strict family inclusion between universes in the model.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Daniel R. Licata",
          "Guillaume Brunerie"
        ],
        "doi": "10.1007/978-3-319-03545-1_1",
        "key": "hutchison_pi_n_2013",
        "raw": "hutchison_pi_n_2013: address = {Cham}, title = {$\\pi_n({S})^n$ in {Homotopy} {Type} {Theory}}, volume = {8307}, isbn = {978-3-319-03544-4 978-3-319-03545-1}, language = {en}, urldate = {2025-02-20}, booktitle = {Certified {Programs} and {Proofs}}, publisher = {Springer International Publishing}, author = {Licata, Daniel R. and Brunerie, Guillaume}, editor = {Hutchison, David and Kanade, Takeo and Kittler, Josef and Kleinberg, Jon M. and Mattern, Friedemann and Mitchell, John C. and Naor, Moni and Nierstrasz, Oscar and Pandu Rangan, C. and Steffen, Bernhard and Sudan, Madhu and Terzopoulos, Demetri and Tygar, Doug and Vardi, Moshe Y. and Weikum, Gerhard and Gonthier, Georges and Norrish, Michael}, year = {2013}, doi = {10.1007/978-3-319-03545-1_1}, note = {Series Title: Lecture Notes in Computer Science}, pages = {1--16}",
        "title": "pin(S)n in Homotopy Type Theory",
        "url": null,
        "venue": "Certified Programs and Proofs",
        "year": 2013
      },
      "exists": null,
      "explanation": "Cited as an example of computing homotopy groups synthetically in HoTT.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Benedikt Ahrens",
          "Krzysztof Kapulkin",
          "Michael Shulman"
        ],
        "doi": "10.1017/S0960129514000486",
        "key": "ahrens_univalent_2015",
        "raw": "ahrens_univalent_2015: title = {Univalent categories and the {Rezk} completion}, volume = {25}, copyright = {https://www.cambridge.org/core/terms}, issn = {0960-1295, 1469-8072}, url = {https://www.cambridge.org/core/product/identifier/S0960129514000486/type/journal_article}, doi = {10.1017/S0960129514000486}, abstract = {We develop category theory within Univalent Foundations, which is a foundational system for mathematics based on a homotopical interpretation of dependent type theory. In this system, we propose a definition of â€˜categoryâ€™ for which equality and equivalence of categories agree. Such categories satisfy a version of the univalence axiom, saying that the type of isomorphisms between any two objects is equivalent to the identity type between these objects; we call them â€˜saturatedâ€™ or â€˜univalentâ€™ categories. Moreover, we show that any category is weakly equivalent to a univalent one in a universal way. In homotopical and higher-categorical semantics, this construction corresponds to a truncated version of the Rezk completion for Segal spaces, and also to the stack completion of a prestack.}, language = {en}, number = {5}, urldate = {2025-02-20}, journal = {Mathematical Structures in Computer Science}, author = {Ahrens, Benedikt and Kapulkin, Krzysztof and Michael Shulman}, month = jun, year = {2015}, pages = {1010--1039}, file = {Full Text:/home/fernando/Zotero/storage/QZ5RZ9HZ/Ahrens et al. - 2015 - Univalent categories and the Rezk completion.pdf:application/pdf}",
        "title": "Univalent categories and the Rezk completion",
        "url": null,
        "venue": "Mathematical Structures in Computer Science",
        "year": 2015
      },
      "exists": null,
      "explanation": "Background reference for univalent category theory.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Lars Birkedal",
          "Ranald Clouston",
          "Bassel Mannaa",
          "Rasmus Ejlers Møgelberg",
          "Andrew M. Pitts",
          "Bas Spitters"
        ],
        "doi": "10.1017/S0960129519000197",
        "key": "birkedalModalDependentType2020",
        "raw": "birkedalModalDependentType2020: title = {Modal Dependent Type Theory and Dependent Right Adjoints}, author = {Birkedal, Lars and Clouston, Ranald and Mannaa, Bassel and Ejlers M{\\o}gelberg, Rasmus and Pitts, Andrew M. and Spitters, Bas}, year = 2020, month = feb, journal = {Mathematical Structures in Computer Science}, volume = {30}, number = {2}, pages = {118--138}, issn = {0960-1295, 1469-8072}, doi = {10.1017/S0960129519000197}, urldate = {2025-06-22}, abstract = {Abstract In recent years, we have seen several new models of dependent type theory extended with some form of modal necessity operator, including nominal type theory, guarded and clocked type theory and spatial and cohesive type theory. In this paper, we study modal dependent type theory : dependent type theory with an operator satisfying (a dependent version of) the K axiom of modal logic. We investigate both semantics and syntax. For the semantics, we introduce categories with families with a dependent right adjoint (CwDRA) and show that the examples above can be presented as such. Indeed, we show that any category with finite limits and an adjunction of endofunctors give rise to a CwDRA via the local universe construction. For the syntax, we introduce a dependently typed extension of Fitch-style modal {$\\lambda$} -calculus, show that it can be interpreted in any CwDRA, and build a term model. We extend the syntax and semantics with universes.}, copyright = {https://www.cambridge.org/core/terms}, langid = {english}, file = {/home/fernando/Zotero/storage/YT6FD9SA/Birkedal et al. - 2020 - Modal dependent type theory and dependent right adjoints.pdf}",
        "title": "Modal Dependent Type Theory and Dependent Right Adjoints",
        "url": null,
        "venue": "Mathematical Structures in Computer Science",
        "year": 2020
      },
      "exists": null,
      "explanation": "Cited for the interpretation of certain operators as dependent right adjoints.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Niels Van Der Weide",
          "Nima Rasekh",
          "Benedikt Ahrens",
          "Paige Randall North"
        ],
        "doi": "10.1145/3636501.3636955",
        "key": "van_der_weide_univalent_2024",
        "raw": "van_der_weide_univalent_2024: address = {London UK}, title = {Univalent {Double} {Categories}}, isbn = {9798400704888}, url = {https://dl.acm.org/doi/10.1145/3636501.3636955}, doi = {10.1145/3636501.3636955}, language = {en}, urldate = {2025-02-20}, booktitle = {Proceedings of the 13th {ACM} {SIGPLAN} {International} {Conference} on {Certified} {Programs} and {Proofs}}, publisher = {ACM}, author = {Van Der Weide, Niels and Rasekh, Nima and Ahrens, Benedikt and North, Paige Randall}, month = jan, year = {2024}, pages = {246--259}, file = {Full Text:/home/fernando/Zotero/storage/7YAP5KFM/Van Der Weide et al. - 2024 - Univalent Double Categories.pdf:application/pdf}",
        "title": "Univalent Double Categories",
        "url": null,
        "venue": "Proceedings of the 13th ACM SIGPLAN International Conference on Certified Programs and Proofs",
        "year": 2024
      },
      "exists": null,
      "explanation": "Background reference for univalence in higher categories.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    },
    {
      "citation": {
        "arxiv_id": null,
        "authors": [
          "Thierry Coquand",
          "Nils Anders Danielsson"
        ],
        "doi": "10.1016/j.indag.2013.09.002",
        "key": "coquand_isomorphism_2013",
        "raw": "coquand_isomorphism_2013: title = {Isomorphism is equality}, volume = {24}, issn = {00193577}, doi = {10.1016/j.indag.2013.09.002}, language = {en}, number = {4}, urldate = {2025-02-20}, journal = {Indagationes Mathematicae}, author = {Coquand, Thierry and Nils Anders Danielsson}, month = nov, year = {2013}, pages = {1105--1120}",
        "title": "Isomorphism is equality",
        "url": null,
        "venue": "Indagationes Mathematicae",
        "year": 2013
      },
      "exists": null,
      "explanation": "Cited for the Structure Identity Principle (SIP) and the idea that equivalent structures are equal.",
      "notes": null,
      "relevance": "medium",
      "resolved_doi": null,
      "resolved_url": null
    }
  ],
  "missing_references": [
    {
      "reason": "The paper extensively discusses straightening-unstraightening and fibrations in category theory, particularly for (op)fibrations and 2-sided fibrations. Lurie's 'Higher Topos Theory' is the definitive modern reference for these constructions in the context of infinity-categories and fibrations.",
      "title": "Higher Topos Theory (Lurie, 2009)"
    },
    {
      "reason": "While the paper cites Street (1974, 1980) for 2-sided fibrations, Benabou's 'Fibered Categories and the Foundations of Naive Category Theory' is a classic reference for the fibred approach to category theory that would be highly relevant to the semantics discussed.",
      "title": "Fibered Categories and the Foundations of Naive Category Theory (Bénabou, 1985)"
    }
  ],
  "summary": "The paper 'Directed type theory, with a twist' is well-referenced, focusing on the historical context of HoTT and MLTT, as well as the recent landscape of directed type theories. It correctly identifies the seminal works of Hofmann & Streicher, Martin-Löf, and the univalent foundations program. The technical part of the paper heavily relies on Ross Street's work on 2-sided fibrations and Bart Jacobs' work on comprehension categories, both of which are appropriately cited. The connections to other directed type theories (by Ahrens, North, Gratzer, Licata, etc.) are clear and well-motivated. Missing references are minor and would mostly serve to provide broader context on higher-categorical straightening results."
}
```

### meta_reviewer (`claude-sonnet-4-6`) — status: `pass`

```json
{
  "confidence": 0.78,
  "questions": [
    "Can the swap/swap^-1 rules be derived from more primitive TTT rules (e.g., via the op-Σ interaction and straightening), or are they genuinely independent postulates? If independent, what is the explicit categorical operation they correspond to in the category model, and can their soundness be proved directly from the D2SFib structure?",
    "How does TTT relate to Neumann–Altenkirch's generalized-algebraic-theory presentation of directed type theory? In particular, does TTT admit a GAT presentation, and would that yield admissibility of substitution and subject reduction as standard consequences?",
    "The Π-type restriction (requiring Γ^op ⊢ A and Γ⋉^- a:A ⊢ B) is presented as necessary to avoid the opfibration obstruction — is there a concrete counterexample demonstrating that unrestricted Π would fail, or is the restriction merely known to be sufficient?",
    "What is the intended strategy for extending TTT to higher-categorical settings such as (∞,1)-categories or bicategories, and does the twisting operation generalize cleanly, or does it require fundamentally new semantic machinery at each level?"
  ],
  "recommendation": "major_revision",
  "strengths": [
    "The twisting operation and D2SFib framework are a genuinely novel semantic contribution that advances the state of directed type theory, satisfying a long-standing desideratum that closed types directly correspond to categories.",
    "The straightening-unstraightening theorem for D2SFibs (Prop prop:straight-d2sfibs) is the paper's strongest technical result: the appendix construction is explicit, the unit and counit are identified, and the categorical argument is plausible and largely complete.",
    "The synthetic derivation of the natural-transformations type (Prop prop:internal-nat-pi) is clean, the five-step isomorphism chain is fully cross-referenced to earlier propositions, and the result corresponds correctly to the standard end formula.",
    "The paper is honest about its limitations: the authors explicitly acknowledge that swap/swap^-1 are ad hoc technical tools, that the Π-type restriction is necessary to avoid a known obstruction, and that meta-theoretic properties remain open.",
    "Literature positioning is thorough: connections to North, Street (1974, 1980), Jacobs (1993), Licata-Harper, Ahrens-North-Van Der Weide, Riehl-Shulman, and New-Licata are all present and correctly characterized.",
    "Novelty relative to competing approaches is clearly articulated: TTT's semantic guarantee (closed types are categories, not bisimplicial sets) is a genuine differentiator from Simplicial Type Theory."
  ],
  "summary": "This paper introduces Twisted Type Theory (TTT), a directed type theory extending North's 1-category model with a novel twisting operation and dependent 2-sided fibrations (D2SFibs). The novelty assessment is strong (score 0.85, verdict: significant), and the literature coverage is thorough and appropriate. The core categorical framework — types as categories, D2SFib straightening-unstraightening, and the natural-transformations result — is sound in outline and well-argued. However, the reproducibility specialist flagged two critical-severity gaps (no mechanized formalization of the headline TTT metatheory; no mechanized straightening-unstraightening proof) and the technical-correctness specialist flagged four major issues collectively bearing on the same root cause: the soundness of the ad hoc swap/swap^-1 rules in the category model is unestablished despite being load-bearing for the Yoneda proof; the Hom-elimination bifunctoriality argument has an implicit gap; and the judgemental status of Hom-Comp is asserted without invoking the required splitness of the cloven D2SFib explicitly. No meta-theoretic properties (subject reduction, normalization, canonicity, decidability) are established or even conjectured. These deficiencies are addressable through revision — either by mechanizing the critical components (paralleling the Coq/UniMath development cited for bicategorical type theory) or by providing explicit paper proofs for the load-bearing gaps — but they are substantial enough to require a major revision rather than minor corrections.",
  "weaknesses": [
    "No mechanized formalization is provided for any part of the TTT metatheory — syntax, twist rule, Hom rules, or category-model interpretation — despite a directly analogous Coq/UniMath formalization existing for bicategorical type theory (Ahrens–North–Van Der Weide, cited). This is a critical reproducibility gap given the complexity of the rule set. [Reproducibility: critical; C1: major]",
    "The soundness of the ad hoc swap/swap^-1 rules in the category model is not established. These rules are introduced solely to enable the Yoneda proof (Lemma yoneda-perm-proof) and their semantic validation is therefore load-bearing for the paper's main application. [C11: major; Reproducibility: critical]",
    "The Hom-elimination proof (C3) has an implicit gap: bifunctoriality of the motive D over A^→⋉X[dom]^op is invoked in the appendix diagram but never stated as a lemma or proved, and the judgemental (rather than propositional) status of Hom-Comp is asserted without explicitly invoking splitness of the cloven D2SFib. [C3: major]",
    "The Ψ∘Φ direction of the Yoneda proof relies on a ten-step context-isomorphism chain (Lemma yoneda-perm-proof) that the authors themselves describe as 'quite technical'; with swap/swap^-1 unverified and no mechanized check, the correctness of this argument remains under-verified. [C6: major]",
    "No meta-theoretic properties are established or conjectured (subject reduction, normalization, canonicity, decidability of typechecking), leaving open whether TTT is usable as a formal foundation. Comparable directed type theories (e.g., Neumann–Altenkirch via GATs) obtain admissibility of substitution by construction. [C10: minor]",
    "No executable prototype, reference typechecker, or regression suite is provided; readers cannot mechanically check whether the displayed derivations typecheck under the intended restrictions. [Reproducibility: major]",
    "The naturality-in-A-and-B argument for the fibred refinement of the D2SFib equivalence is dispatched in a single sentence; while plausible, an explicit verification is warranted given that the fibred structure is relied upon downstream. [C2: info, but worth addressing]"
  ]
}
```

### novelty (`gemini-3-flash-preview`) — status: `pass`

```json
{
  "confidence": 0.9,
  "missing_prior_art": [
    {
      "reason": "This 2023 thesis also uses the 'twisted' terminology and concept to address non-invertible paths in Homotopy Type Theory, albeit through a cubical rather than a 1-categorical fibration approach. It is relevant prior art for directed type theories attempting to resolve the 'twist' between covariant and contravariant dependencies.",
      "title": "Twisted Cubes and their Applications in Type Theory (Gun Pinyo, 2023)"
    }
  ],
  "novelty_score": 0.85,
  "related_work": [
    {
      "citation_key": "north_towards_2019",
      "delta": "TTT extends North's category model by introducing the twisting operation and D2SFibs, which allows for a Hom-introduction rule that correctly interprets as the arrow category, satisfying a key desideratum that North's theory did not meet.",
      "relation": "builds_on",
      "title": "Towards a Directed Homotopy Type Theory"
    },
    {
      "citation_key": "riehl_type_2017",
      "delta": "Unlike Simplicial Type Theory (STT), TTT ensures that all closed types correspond semantically to categories rather than more general bisimplicial sets, reducing category-checking to type-checking.",
      "relation": "competing",
      "title": "A type theory for synthetic infinity-categories"
    },
    {
      "citation_key": "licata_2-dimensional_2011",
      "delta": "TTT introduces Hom-types with explicit formation, introduction, elimination, and computation rules, which were absent in the 2-dimensional directed type theory of Licata & Harper.",
      "relation": "prior_art",
      "title": "2-Dimensional Directed Type Theory"
    }
  ],
  "verdict": "significant"
}
```

### reproducibility (`gpt-5.5`) — status: `pass`

```json
{
  "code_availability": "unspecified",
  "code_url": null,
  "concerns": [
    {
      "area": "code",
      "description": "No formal verification artifact is provided for the headline TTT metatheory. A proof-assistant development such as `formal/TTT/Syntax.agda` or `formal/TTT/Syntax.lean` encoding the syntax, twist rule, Hom rules, and category-model interpretation would close this proof-as-code gap.",
      "severity": "critical"
    },
    {
      "area": "code",
      "description": "The straightening-unstraightening equivalence for dependent 2-sided fibrations is central but only presented as paper proofs. A mechanized artifact such as `formal/TTT/D2SFib/Straightening.agda` covering the D2SFib definitions, functors, and equivalence would be needed for reproducible formal checking.",
      "severity": "critical"
    },
    {
      "area": "code",
      "description": "The syntactic Yoneda lemma application depends on multiple derived rules and context permutations, but no typechecker or proof script is supplied. A checkable file such as `formal/TTT/Applications/Yoneda.agda` would make the main example reproducible.",
      "severity": "major"
    },
    {
      "area": "evaluation",
      "description": "There is no executable prototype, reference typechecker, or regression suite for the proposed Twisted Type Theory rules, so readers cannot mechanically test whether the displayed derivations typecheck under the intended restrictions.",
      "severity": "major"
    },
    {
      "area": "data",
      "description": "No empirical dataset is involved; data availability is therefore not a limiting factor, but the paper also does not provide machine-readable source artifacts for the formal statements beyond the extracted manuscript content.",
      "severity": "info"
    },
    {
      "area": "other",
      "description": "Verifier could not reach `https://people.cs.kuleuven.be/` (status=network_error)",
      "severity": "minor"
    }
  ],
  "confidence": 0.86,
  "data_availability": "unspecified",
  "data_url": null,
  "environment": null,
  "reproducibility_score": 0.24
}
```

### summary (`claude-haiku-4-5-20251001`) — status: `pass`

```json
{
  "audience": "Type theorists and mathematical logicians working on directed type theories, category theorists interested in formal foundations and internal languages, developers of proof assistants seeking richer categorical reasoning, and researchers in mathematical logic studying semantics of dependent type systems.",
  "key_contributions": [
    "Introduction of Twisted Type Theory (TTT), a new directed type theory extending North's category model with a novel twisting operation and modified Hom-type rules",
    "Development of dependent 2-sided fibrations (D2SFibs) as a generalization of Street's 2-sided fibrations, with a complete straightening-unstraightening characterization",
    "A type theory where types in the empty context directly correspond to categories, enabling direct verification that constructions preserve categorical structure",
    "New elimination rules for Hom-types that support both reasoning about natural transformations and compatibility with higher-dimensional extensions",
    "Demonstration that TTT enables HoTT-like proof techniques in the directed setting, with a syntactic proof of Yoneda's lemma"
  ],
  "plain_language_summary": "Homotopy Type Theory (HoTT) successfully treats mathematics and geometry by interpreting types as spaces and equality proofs as paths. However, many mathematical structures—particularly categories and functors—are inherently directional rather than symmetric. This paper proposes Twisted Type Theory (TTT), a new directed type theory where types correspond to categories instead of groupoids. The key innovation is a \"twisting\" operation: given a type that depends on variables in both forward and backward ways, twisting produces a new type depending only on forward dependencies. This operation recovers the arrow category construction from Street's classical work on fibrations and enables the paper's three core design goals: types as categories, emergent categorical structure through Hom-types, and proper handling of directed equalities. The paper develops dependent 2-sided fibrations (D2SFibs) as the semantic foundation and proves key results including a straightening-unstraightening theorem. By applying TTT to reason about categories, the authors provide a syntactic proof of Yoneda's lemma—a foundational result in category theory.",
  "tldr": "This paper introduces Twisted Type Theory, a novel directed type theory featuring a twisting operation on types and dependent 2-sided fibrations, enabling type-theoretic reasoning about categories while maintaining HoTT-like proof techniques."
}
```

### technical_correctness (`claude-opus-4-7`) — status: `pass`

```json
{
  "claims": [
    {
      "assessment": "partially_supported",
      "claim": "Twisted Type Theory (TTT) satisfies all three stated desiderata: (1) closed types are categories, (2) Hom-types are introduced via formation/intro/elim/comp rules, and (3) the Hom-introduction rule corresponds to the factorization A → A^→ → A×A of the diagonal.",
      "evidence": "Desideratum (1) follows from working in North's category model where closed types are interpreted as categories (Definition def:catmodel). Desideratum (2) is supported by the rules in Figure fig:hom and Propositions hom-intro/Hom-Elim/Hom-Comp. Desideratum (3) is established in the proof of prop:hom-intro by exhibiting an isomorphism between Interp{Γ ⊢ b:A ⊢ a:A tscxe Hom_A(ā,b)} and Γ ⋉ A^→. However, the equivalence with the model-categorical factorization is argued informally; no formal verification (Coq/Agda/Lean) of the soundness of the full rule set with respect to the category model is provided.",
      "id": "C1",
      "location": "Introduction; Section 4 (Twisted Type Theory)",
      "severity": "major",
      "suggested_fix": "Provide a mechanized formalization of the comprehension category structure and the soundness of the TTT rules (including Twist, Hom-Intro, Hom-Elim, Hom-Comp) in a proof assistant such as Coq/UniMath, Agda, or Lean — e.g., `formalization/TTT/CategoryModel.v` paralleling Ahrens–North–Van Der Weide's Coq formalization of bicategorical type theory (cited as [@ahrensBicategoricalTypeTheory2023])."
    },
    {
      "assessment": "supported",
      "claim": "There is a fibred equivalence of categories tye^* : DProf ≃ D2SFib over ICat_str (Proposition prop:straight-d2sfibs), generalizing Street's Grothendieck construction for profunctors.",
      "evidence": "The appendix gives an explicit construction: unstraightening Φ:[A⋉B^op,Cat] → D2SFib(A,B) verifies conditions (3)–(6) of D2SFib definition; straightening Ψ takes fibres and uses Lemma d2sfib:lemma to establish functoriality. The unit η is identity (object-level) and counit ε is constructed via universal properties of (op)cartesian lifts. Naturality in A,B for the fibred refinement is asserted (one sentence: 'follows from the previous proposition, by noting that each construction given is natural in A and B') but plausible given that all constructions are pointwise and use only universal properties.",
      "id": "C2",
      "location": "Section 3 (Theorem prop:straight-d2sfibs); full proof in Appendix Section 8",
      "severity": "info",
      "suggested_fix": "Expand the proof of naturality in A and B (currently a one-line remark) into an explicit verification that the equivalence Φ ⊣ Ψ is fibred over ICat_str, or supply a mechanized check (e.g. `formalization/Straightening.agda`)."
    },
    {
      "assessment": "partially_supported",
      "claim": "The Hom-elimination rule (a generalized J-rule for Hom-types whose motive D may depend on an additional variable x:X) is validated by the category model, with the corresponding Hom-Comp judgemental equality.",
      "evidence": "The proof sketch constructs j on objects by exploiting that (id_a,f):id_a → f is a morphism in A^→(γ), allowing transport of d*(γ,a,x) ∈ D(γ,id_a,x) along the canonical morphism φ. The appendix extends this to morphisms via a transport along D(id_γ',(id_a',f'),id_{X(θ,α)x}). However: (i) the diagram on p. 49 of the appendix asserts commutativity of a six-cell square that depends on bifunctoriality of D viewed as a dependent profunctor on A^→⋉X[dom]^op, but this bifunctoriality is not explicitly proved (only invoked); (ii) the strictness/equality (versus isomorphism) of the resulting j vs. the prescribed action on Refl_a (Hom-Comp) is asserted to hold judgementally, which on the categorical side becomes a strict equality of functors. The construction uses cartesian lifts that, in the cloven split D2SFib, are unique but the proof should explicitly invoke splitness to obtain a strict equality.",
      "id": "C3",
      "location": "Section 4.1 (Hom-Elim proposition); appendix Section 9.1",
      "severity": "major",
      "suggested_fix": "Add an explicit lemma in Section 9.1 stating bifunctoriality of D on A^→⋉X[dom]^op and citing where this is used. Make explicit how splitness of (op)fibrational data ensures Hom-Comp is a judgemental (not propositional) equality. Ideally, mechanize j and Hom-Comp in a proof assistant (e.g., `formalization/HomElim.lean`)."
    },
    {
      "assessment": "partially_supported",
      "claim": "Directed univalence holds in the category model: for sets Γ^op ⊢ A:Set and Γ ⊢ B:Set, the judgemental equality Γ ⊢ A → B ≡ Hom_Set(A,B):Set is validated.",
      "evidence": "For discrete A,B (i.e. sets), the category [A,B] is itself discrete and naturally isomorphic to the set hom_Set(A,B). The proposition is stated without proof beyond 'by the previous discussion' (i.e., that [A,B] is a set when A,B are sets). This is correct on the categorical side, but the *judgemental* equality A → B ≡ Hom_Set(A,B) (as opposed to a propositional equivalence) requires checking that the two interpretations are equal as objects of Cat, not just isomorphic. With discrete (Coquand) universes, this is typically the case, but a half-line proof would make this transparent.",
      "id": "C4",
      "location": "Section 5.1, Definition def:dunivalence and Proposition prop:dunivalence",
      "severity": "minor",
      "suggested_fix": "State explicitly that for the discrete universe Set, the interpretations Interp{A → B} and Interp{Hom_Set(A,B)} are equal (not merely isomorphic) as objects, and add one sentence of justification (e.g., 'both are the discrete category whose underlying set is hom_Set(Interp{A},Interp{B})')."
    },
    {
      "assessment": "supported",
      "claim": "Proposition prop:internal-nat-pi: For copresheaves F,G:A→Set, the type Nat(F,G) := Π_{(a,x):Σ_{a:A}Fa} Ga is interpreted as the set of natural transformations Interp{F} → Interp{G}.",
      "evidence": "The chain of five isomorphisms is sound, each step citing an earlier proposition: Π-types (prop:pi-types) → Σ-types (prop:Sigma) → function-twist (prop:function-twist) → directed univalence (prop:dunivalence) → internal-nat-hom (prop:internal-nat-hom). The final result corresponds to the standard end formula Nat(F,G) = ∫_a [Fa,Ga], which for Set-valued copresheaves over a 1-category reduces to the Π-Σ formula given. The lax-end remark (remark:lax-ends) further situates this within (co)end calculus, consistent with Loregian [@loregianCoendCalculus2021].",
      "id": "C5",
      "location": "Section 5.2; chain of isomorphisms in proof",
      "severity": "info",
      "suggested_fix": null
    },
    {
      "assessment": "partially_supported",
      "claim": "The Yoneda lemma admits a synthetic proof in TTT: for A:U a closed type, Y(F,a)=Nat(Hom_A(a,-),F) and Ȳ(F,a)=Fa are naturally isomorphic functors (A→Set)×A → Set.",
      "evidence": "The forward map Φ is evaluation at Refl_a, which is well-typed. The backward map Ψ is defined via Hom-elimination: j(f,r,r) for f:Hom_A(a,x), r:Fa. Φ∘Ψ = id follows from the Hom-Comp computation rule by direct substitution (j(Refl_a,r,r)=r). Ψ∘Φ = id is argued by 'another application of Hom-elimination', but the appendix proof relies on Lemma lemma:yoneda-perm-proof which is an extended chain of ten context isomorphisms involving opposite contexts, twists, and Σ-types, including the swap/swap^-1 rules whose role is only to enable this rearrangement (acknowledged in a remark as a 'technical tool'). The authors themselves note in §6 that 'the rules for permuting contexts involving twisted types could be improved' and that 'our current proof of its correctness is quite technical'. While each step is individually plausible, the cumulative absence of any mechanized check, combined with the use of swap/swap^-1 rules introduced ad hoc precisely to make this proof go through, leaves the proof's correctness under-verified.",
      "id": "C6",
      "location": "Section 5.3 (Lemma lemma:yoneda); full proof in Appendix Section 9.2",
      "severity": "major",
      "suggested_fix": "Mechanize at least the swap/swap^-1 rules and Lemma yoneda-perm-proof in a proof assistant, e.g. `formalization/Yoneda.lean` or `formalization/Yoneda.agda`. Alternatively, derive swap/swap^-1 from more primitive rules (e.g., via the strict family inclusion and the Σ/op rules) rather than postulating them. The closest analogue is Riehl–Shulman's simplicial type theory, whose Yoneda proof has been formalized in the RZK proof assistant — a comparable artifact would substantially strengthen this contribution."
    },
    {
      "assessment": "partially_supported",
      "claim": "There exists a displayed category model: a full split comprehension category over Cat whose comprehension is the unstraightening functor (⋉^d)^*:DCat → Cat^→, inducing a fibred equivalence over Cat (Proposition prop:dcat-model and Definition def:dcat-model).",
      "evidence": "The construction is attributed as 'folklore' and the proof sketch invokes Loregian [@loregianCoendCalculus2021 Theorem 5.4.5] for the equivalence between lax normal functors A → Cat_Prof and arbitrary functors over A. The application of Loregian's theorem to the *split* (not merely weakly equivalent) version requires care: pseudofunctoriality of the pullback (⋉^d)^* under reindexing must be tracked to ensure the resulting comprehension category is actually split. The paper does not explicitly verify splitness of the unstraightening or that the strict pullback F^*U respects identity reindexing strictly; the remark 'the existence of the displayed category model is folklore' suggests the authors did not feel obligated to do so.",
      "id": "C7",
      "location": "Section 2.2",
      "severity": "minor",
      "suggested_fix": "Add a short subsection or appendix lemma explicitly checking that the strict pullback F^*U:A×_Cat_Prof (Cat_Prof)_* → A is functorial in A on the nose (preserving identity and composition strictly), so that the resulting comprehension category is genuinely split. Cite or reproduce the splitness argument from Loregian rather than relying on the folklore status."
    },
    {
      "assessment": "supported",
      "claim": "The category model has strong Σ-types, Π-types (under restricted conditions), and validates opposite types and Hom-types (Proposition prop:Sigma, prop:pi-types).",
      "evidence": "The construction of Σ via the standard Grothendieck-like assembly with morphisms (α,β) where β:B(id_γ,α)b → b' is consistent with North's category model. The restriction of Π to Γ^op ⊢ A,Ty and Γ⋉^- a:A ⊢ B,Ty correctly avoids the well-known obstruction that dependent products of opfibrations along arbitrary functors are not opfibrations (acknowledged via [@licata_2-dimensional_2011; @neumannSynthetic1CategoriesDirected2025]). The interpretation of opposite types via postcomposition with op:Cat→Cat is standard.",
      "id": "C8",
      "location": "Section 2.1 and Section 4.2",
      "severity": "info",
      "suggested_fix": null
    },
    {
      "assessment": "partially_supported",
      "claim": "For each indexed category B:A→Cat, D2SFibs from A to B form a fibred category DTSFib over ICat_str (Lemma at the end of Section 3).",
      "evidence": "The paper states this as a 'routine lemma' but provides no proof beyond observing that pullback along ⋉^*(F,G) preserves the D2SFib structure. Pseudofunctoriality on ICat_str is asserted but not verified. While plausible (since (op)cartesian lifts pull back along cartesian morphisms), the verification that condition (6) (commutativity of the Beck–Chevalley-like square) is preserved under arbitrary base change is non-trivial and merits at least an outline.",
      "id": "C9",
      "location": "Section 3, paragraph after Definition def:d2sfib-1cells",
      "severity": "minor",
      "suggested_fix": "Provide a brief proof or appendix lemma verifying that the pullback construction preserves conditions (3)–(6) of Definition def:d2sfib and is pseudofunctorial on ICat_str."
    },
    {
      "assessment": "unsupported",
      "claim": "All meta-theoretic properties standard for type theories (e.g., subject reduction, normalization, canonicity, decidability of typechecking) hold for TTT.",
      "evidence": "The paper presents TTT purely as a syntax with categorical semantics; it does not claim or prove subject reduction, normalization, canonicity, or decidability of type checking. The authors are explicit that the contribution is the categorical structure and the synthetic proofs, not a full meta-theory. However, for a 'directed type theory' to be usable as a foundation, at least some meta-theory is needed; the lack of any meta-theoretic results is a notable gap relative to comparable work (e.g., Neumann–Altenkirch obtain a syntactic model via generalized algebraic theories).",
      "id": "C10",
      "location": "Not stated in the paper",
      "severity": "minor",
      "suggested_fix": "Add a 'Meta-theory' subsection (possibly in future work) stating which properties are conjectured and which are open. Following Neumann–Altenkirch [@neumannSynthetic1CategoriesDirected2025], a GAT presentation would automatically yield a syntactic model and admissibility of substitution. Alternatively, mechanize the syntax in a proof assistant so the rules are verified to typecheck on at least one model."
    },
    {
      "assessment": "partially_supported",
      "claim": "The new swap and swap^-1 operations for Σ-types (Figure fig:sigma) are admissible / sound in the category model, despite being introduced ad hoc to enable the Yoneda proof.",
      "evidence": "The remark in Section 7 states that swap and swap^-1 are 'a technical tool to facilitate rearrangements of the data in contexts with twisted types' and are only used in the proof of Lemma yoneda-perm-proof. The rules themselves are not explicitly shown in the prompt's excerpt (Figure fig:sigma is referenced but not rendered with text), and no soundness proof for them in the category model is given. Since they are postulated specifically to make the Yoneda derivation type-check, their semantic validation is load-bearing.",
      "id": "C11",
      "location": "Section 7 (Complete description of TTT); used in Section 9.2",
      "severity": "major",
      "suggested_fix": "Provide explicit rule statements and a soundness proof for swap and swap^-1 in the category model (likely via Proposition prop:op-sigma plus straightening). If they cannot be derived from more primitive rules, justify their admissibility on semantic grounds and ideally mechanize them in a proof assistant (e.g. `formalization/Swap.agda`)."
    }
  ],
  "confidence": 0.62,
  "overall_correctness": "mostly_sound"
}
```

## Corrections

<!-- corrections-section: rendered from corrections table; empty on first publish -->
_No corrections have been recorded._

## Bibliography

_No bibliography extracted._

